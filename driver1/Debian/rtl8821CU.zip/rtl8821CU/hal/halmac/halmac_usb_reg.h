#ifndef __HALMAC_USB_REG_H__
#define __HALMAC_USB_REG_H__





#endif/* __HALMAC_USB_REG_H__ */
